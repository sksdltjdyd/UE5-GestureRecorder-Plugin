#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GestureRecorderComponent.generated.h"

class USkeletalMeshComponent;

// 🎯 언리얼 뼈 이름과 MediaPipe имен을 매핑해주는 구조체
USTRUCT(BlueprintType)
struct FGestureBoneMapping
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bone Mapping")
	FName UEBoneName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bone Mapping")
	FString MediaPipeName;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class GESTURERECORDER_API UGestureRecorderComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UGestureRecorderComponent();

protected:
	virtual void BeginPlay() override;

public:	
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Recording")
	TObjectPtr<USkeletalMeshComponent> TargetMesh;

	UPROPERTY(EditAnywhere, Category = "Recording|Bones")
	FName RootBoneName = TEXT("pelvis");

	// 🎯 단순 배열에서 번역용 구조체 배열로 변경
	UPROPERTY(EditAnywhere, Category = "Recording|Bones")
	TArray<FGestureBoneMapping> TargetBones;

	UPROPERTY(EditAnywhere, Category = "Recording|Scale")
	float NormalizeScale = 0.01f;

	UPROPERTY(EditAnywhere, Category = "Recording")
	float RecordInterval = 0.0333f;

	UPROPERTY(EditAnywhere, Category = "Recording")
	FString BaseFileName = TEXT("GestureData");

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void StartRecording();

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void StopRecording();

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void UpdateGestureInfo(FString Name, int32 Count);

private:
	FTimerHandle RecordTimerHandle;
	bool bIsRecording;
	
	FString CurrentGestureName; 
	int32 CurrentGestureCount; 

	TArray<FString> RecordedData;

	void RecordFrame();
};