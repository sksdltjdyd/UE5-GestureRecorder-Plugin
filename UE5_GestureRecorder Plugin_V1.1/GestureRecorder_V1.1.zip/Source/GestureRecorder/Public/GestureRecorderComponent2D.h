#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GestureRecorderComponent2D.generated.h"

class USkeletalMeshComponent;

// 이름 충돌 방지를 위해 2D용 구조체 분리
USTRUCT(BlueprintType)
struct FGestureBoneMapping2D
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bone Mapping")
	FName UEBoneName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Bone Mapping")
	FString MediaPipeName;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class GESTURERECORDER_API UGestureRecorderComponent2D : public UActorComponent
{
	GENERATED_BODY()

public:	
	UGestureRecorderComponent2D();

protected:
	virtual void BeginPlay() override;

public:	
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Recording")
	TObjectPtr<USkeletalMeshComponent> TargetMesh;

	UPROPERTY(EditAnywhere, Category = "Recording|Bones")
	FName RootBoneName = TEXT("pelvis");

	UPROPERTY(EditAnywhere, Category = "Recording|Bones")
	TArray<FGestureBoneMapping2D> TargetBones;

	UPROPERTY(EditAnywhere, Category = "Recording|Scale")
	float NormalizeScale = 0.01f;

	UPROPERTY(EditAnywhere, Category = "Recording")
	float RecordInterval = 0.0333f;

	UPROPERTY(EditAnywhere, Category = "Recording")
	FString BaseFileName = TEXT("GestureData_2D");

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void StartRecording();

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void StopRecording();

	UFUNCTION(BlueprintCallable, Category = "Recording")
	void UpdateGestureInfo(FString Name, int32 Count);

private:
	FTimerHandle RecordTimerHandle;
	bool bIsRecording;
	
	FString CurrentGestureName; 
	int32 CurrentGestureCount; 

	TArray<FString> RecordedData;

	void RecordFrame();
};