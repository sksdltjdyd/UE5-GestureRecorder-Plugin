#include "GestureRecorderComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"
#include "Misc/DateTime.h"

UGestureRecorderComponent::UGestureRecorderComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	bIsRecording = false;
	CurrentGestureName = TEXT("Idle");
	CurrentGestureCount = 0;

	// 🎯 MediaPipe 표준 랜드마크에 맞춘 기본 매핑 세팅
	auto AddBone = [&](FName InUEBone, FString InMPBone) {
		FGestureBoneMapping NewBone;
		NewBone.UEBoneName = InUEBone;
		NewBone.MediaPipeName = InMPBone;
		TargetBones.Add(NewBone);
	};

	AddBone(TEXT("head"), TEXT("nose"));
	AddBone(TEXT("upperarm_l"), TEXT("left_shoulder"));
	AddBone(TEXT("upperarm_r"), TEXT("right_shoulder"));
	AddBone(TEXT("lowerarm_l"), TEXT("left_elbow"));
	AddBone(TEXT("lowerarm_r"), TEXT("right_elbow"));
	AddBone(TEXT("hand_l"), TEXT("left_wrist"));
	AddBone(TEXT("hand_r"), TEXT("right_wrist"));
	AddBone(TEXT("thigh_l"), TEXT("left_hip"));
	AddBone(TEXT("thigh_r"), TEXT("right_hip"));
	AddBone(TEXT("calf_l"), TEXT("left_knee"));
	AddBone(TEXT("calf_r"), TEXT("right_knee"));
	AddBone(TEXT("foot_l"), TEXT("left_ankle"));
	AddBone(TEXT("foot_r"), TEXT("right_ankle"));
}

void UGestureRecorderComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!TargetMesh)
	{
		TargetMesh = GetOwner()->FindComponentByClass<USkeletalMeshComponent>();
	}
}

void UGestureRecorderComponent::StartRecording()
{
	if (bIsRecording || !TargetMesh) return;

	RecordedData.Empty();

	// 🎯 MediaPipe 이름을 사용하여 CSV 헤더 자동 생성 (3D: X, Y, Z)
	FString DynamicHeader = TEXT("");
	for (const FGestureBoneMapping& BoneMap : TargetBones)
	{
		DynamicHeader += FString::Printf(TEXT("%s_X,%s_Y,%s_Z,"), *BoneMap.MediaPipeName, *BoneMap.MediaPipeName, *BoneMap.MediaPipeName);
	}
	DynamicHeader += TEXT("GestureName,GestureCount");
	
	RecordedData.Add(DynamicHeader);

	bIsRecording = true;
	GetWorld()->GetTimerManager().SetTimer(RecordTimerHandle, this, &UGestureRecorderComponent::RecordFrame, RecordInterval, true);
	
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, FString::Printf(TEXT("3D 녹화 시작: %d개 랜드마크 트래킹 중"), TargetBones.Num()));
}

void UGestureRecorderComponent::StopRecording()
{
	if (!bIsRecording) return;

	bIsRecording = false;
	GetWorld()->GetTimerManager().ClearTimer(RecordTimerHandle);

	FString DirectoryPath = TEXT("E:/02_Work/01_Project/2026.04.15_Microsoft/03_UE5/ONXX_Test/ONXX_Test/Saved/GestureData/");
	
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.DirectoryExists(*DirectoryPath))
	{
		PlatformFile.CreateDirectoryTree(*DirectoryPath);
	}

	FString Timestamp = FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
	FString FullFileName = FString::Printf(TEXT("%s_%s.csv"), *BaseFileName, *Timestamp);
	FString FilePath = DirectoryPath + FullFileName;
	
	FString FinalCSV;
	for (const FString& Line : RecordedData)
	{
		FinalCSV += Line + TEXT("\n");
	}

	if (FFileHelper::SaveStringToFile(FinalCSV, *FilePath))
	{
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Green, FString::Printf(TEXT("저장 완료: %s"), *FullFileName));
	}
}

void UGestureRecorderComponent::UpdateGestureInfo(FString Name, int32 Count)
{
	CurrentGestureName = Name;
	CurrentGestureCount = Count;
}

void UGestureRecorderComponent::RecordFrame()
{
	if (!TargetMesh) return;

	FVector PelvisLocation = TargetMesh->GetSocketLocation(RootBoneName);
	FString FrameData = TEXT("");

	for (const FGestureBoneMapping& BoneMap : TargetBones)
	{
		FVector JointLocation = TargetMesh->GetSocketLocation(BoneMap.UEBoneName);
		FVector RelativeLocation = JointLocation - PelvisLocation;
		RelativeLocation *= NormalizeScale;

		FrameData += FString::Printf(TEXT("%.6f,%.6f,%.6f,"), RelativeLocation.X, RelativeLocation.Y, RelativeLocation.Z);
	}

	FrameData += FString::Printf(TEXT("%s,%d"), *CurrentGestureName, CurrentGestureCount);
	RecordedData.Add(FrameData);
}