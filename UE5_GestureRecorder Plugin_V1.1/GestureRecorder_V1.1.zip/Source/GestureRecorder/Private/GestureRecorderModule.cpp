#include "Modules/ModuleManager.h"

// 엔진에게 'GestureRecorder'라는 모듈의 메인 진입점이라고 알려주는 마법의 매크로입니다.
IMPLEMENT_MODULE(FDefaultModuleImpl, GestureRecorder);